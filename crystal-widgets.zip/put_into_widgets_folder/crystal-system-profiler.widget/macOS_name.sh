#!/bin/bash
#
# macOS_name.sh by locupleto
# https://github.com/locupleto/crystal-widgets
#
# Widget-specific script for system-profiler

# Locate tmp dir for caching
common_script="$(dirname "$0")/../crystal_common.sh"
if [ -f "$common_script" ]; then
    source "$common_script"
fi

getFullName() {
    local version=$1
    local namePattern=$2
    local cache_file="$HTOP_TEMP_DIR/${namePattern// /_}_$version.txt"

    # Check if cache file exists and delete if it's more than 1 day old
    if [ -f "$cache_file" ]; then
        # Find cache file older than 1 day and delete it
        find "$HTOP_TEMP_DIR" -name "${namePattern// /_}_$version.txt" -mtime +1 -exec rm {} \;

        # Check again if the cache file still exists after potential deletion
        if [ -s "$cache_file" ]; then
            cat "$cache_file"
            return 0
        fi
    fi

    # Wait until network is up before attempting to query wikipedia
    while ! ping -c 1 wikipedia.com >/dev/null 2>&1; do sleep 1; done;

    # Query wikit and parse the full name
    local fullName=$($WIKIT_CMD "$namePattern $version" | grep -o -m 1 "$namePattern .* (version $version)" | awk -F "(version $version)" '{print $1 "version '$version')"}')

    # Return and cache the full name if found
    if [[ -n "$fullName" ]]; then
        echo "$fullName"
        echo "$fullName" > "$cache_file"
        return 0
    fi

    # Reduce the version string and try again if necessary
    if [[ $version =~ ^[0-9]+\.[0-9]+ ]]; then
        getFullName "${version%.*}" "$namePattern"
    else
        echo ""
    fi
}

# Ensure HTOP_TEMP_DIR exists
mkdir -p "$HTOP_TEMP_DIR"

# Fetch the current OS version
VERSION=$(sw_vers -productVersion)
NAME_PATTERN=""

# Determine if the version is before macOS Sierra (10.12)
if [[ $VERSION =~ ^10\.[0-9]+$ || $VERSION =~ ^10\.1[0-1]$ ]]; then
    NAME_PATTERN="OS X"
else
    NAME_PATTERN="macOS"
fi

# Start with the most specific version and reduce as needed
FULL_NAME=$(getFullName "$VERSION" "$NAME_PATTERN")

export R1=$(echo "$FULL_NAME" v"$VERSION" | sed -E 's/ \(version [^)]+\)//')