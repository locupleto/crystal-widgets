#!/bin/bash
#
# crystal-system-profiler.widget by locupleto
# https://github.com/locupleto/crystal-widgets
#
# Widget-specific script for system-profiler

export PATH=/opt/homebrew/bin:$PATH

# Locate tmp dir for caching
common_script="$(dirname "$0")/../crystal_common.sh"
if [ -f "$common_script" ]; then
    source "$common_script"
fi
export HTOP_TEMP_DIR=${HTOP_TEMP_DIR:-/tmp}

# Source macOS name script to get OS & version -> $R1
source "$(dirname "$0")/macOS_name.sh"

# Corrected variable assignments
L1=$(system_profiler SPHardwareDataType | grep 'Model Name' | awk -F': ' '{print $2}' | tr -d '\n')
L2=$(system_profiler SPHardwareDataType | grep 'Chip' | awk -F': ' '{print $2}' | tr -d '\n')

# Check if L2 is empty and if so, attempt to get 'Processor Name' and 'Processor Speed'
if [[ -z "$L2" ]]; then
    processor_name=$(system_profiler SPHardwareDataType | grep 'Processor Name' | awk -F': ' '{print $2}' | tr -d '\n')
    processor_speed=$(system_profiler SPHardwareDataType | grep 'Processor Speed' | awk -F': ' '{print $2}' | tr -d '\n')
    L2="${processor_name}"
fi

R2=$(system_profiler SPHardwareDataType | grep 'Memory:' | awk -F': ' '{print $2 " Memory"}')
L3=$(system_profiler SPHardwareDataType | grep 'Total Number of Cores' | awk -F': ' '{print $2}' | awk '{print $1 " cores"}')

# Append processor information to L3 if L2 was initially empty
if [[ -n "$processor_name" ]]; then
    L3="${L3}, ${processor_speed}"
fi

R3=$(diskutil info /dev/disk0 | grep 'Disk Size' | awk '{print $3, $4, "ssd"}')

# Return the values the coffee script needs
echo "$L1;$R1;$L2;$R2;$L3;$R3"
